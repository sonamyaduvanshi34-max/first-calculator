const subjectCount = document.getElementById("subjectCount");
const generateBtn = document.getElementById("generateBtn");
const subjectsContainer = document.getElementById("subjects");
const marksForm = document.getElementById("marksForm");
const resetBtn = document.getElementById("resetBtn");
const error = document.getElementById("error");
const results = document.getElementById("results");

// Create subject input fields
function generateSubjects() {
  const count = Number(subjectCount.value);

  if (!Number.isInteger(count) || count < 1 || count > 50) {
    error.textContent = "Enter a number between 1 and 50.";
    return false;
  }

  subjectsContainer.replaceChildren();
  error.textContent = "";
  results.hidden = true;

  for (let i = 0; i < count; i++) {
    const row = document.createElement("div");
    row.className = "subject-row";

    const nameField = document.createElement("div");
    nameField.className = "subject-name";

    const nameLabel = document.createElement("label");
    nameLabel.className = "field-label";
    nameLabel.htmlFor = `name-${i}`;
    nameLabel.textContent = `Subject ${i + 1}`;

    const nameInput = document.createElement("input");
    nameInput.id = `name-${i}`;
    nameInput.value = `Subject ${i + 1}`;
    nameInput.maxLength = 60;
    nameInput.required = true;

    nameField.append(nameLabel, nameInput);

    const obtainedField = createField(
      `obtained-${i}`, "Marks obtained", "100"
    );

    const maximumField = createField(
      `maximum-${i}`, "Maximum marks", "100"
    );

    row.append(nameField, obtainedField, maximumField);
    subjectsContainer.appendChild(row);
  }

  return true;
}

function createField(id, labelText, defaultValue) {
  const wrapper = document.createElement("div");

  const label = document.createElement("label");
  label.className = "field-label";
  label.htmlFor = id;
  label.textContent = labelText;

  const input = document.createElement("input");
  input.id = id;
  input.type = "number";
  input.min = "0";
  input.step = "any";
  input.value = defaultValue;
  input.required = true;

  wrapper.append(label, input);
  return wrapper;
}

marksForm.addEventListener("submit", function (event) {
  event.preventDefault();
  error.textContent = "";
  results.hidden = true;

  const count = Number(subjectCount.value);
  let total = 0;
  let maximumTotal = 0;

  if (!Number.isInteger(count) || count < 1 || count > 50) {
    error.textContent = "Enter between 1 and 50 subjects.";
    return;
  }

  for (let i = 0; i < count; i++) {
    const nameInput = document.getElementById(`name-${i}`);
    const obtainedInput = document.getElementById(`obtained-${i}`);
    const maximumInput = document.getElementById(`maximum-${i}`);

    const name = nameInput.value.trim();
    const obtained = Number(obtainedInput.value);
    const maximum = Number(maximumInput.value);

    if (
      !name ||
      obtainedInput.value.trim() === "" ||
      maximumInput.value.trim() === "" ||
      !Number.isFinite(obtained) ||
      !Number.isFinite(maximum) ||
      maximum <= 0 ||
      obtained < 0 ||
      obtained > maximum
    ) {
      error.textContent =
        `Please check the marks entered for Subject ${i + 1}.`;
      return;
    }

    total += obtained;
    maximumTotal += maximum;
  }

  const percentage = (total / maximumTotal) * 100;
  let grade;
  let feedback;

  if (percentage >= 90) {
    grade = "A";
    feedback = "Excellent work!";
  } else if (percentage >= 80) {
    grade = "B";
    feedback = "Great job!";
  } else if (percentage >= 70) {
    grade = "C";
    feedback = "Good effort!";
  } else {
    grade = "Need Improvement";
    feedback = "Keep practicing!";
  }

  document.getElementById("total").textContent = total;
  document.getElementById("maximum").textContent = maximumTotal;
  document.getElementById("percentage").textContent =
    percentage.toFixed(2) + "%";
  document.getElementById("grade").textContent =
    grade === "Need Improvement" ? grade : `Grade ${grade}`;
  document.getElementById("feedback").textContent = feedback;

  results.hidden = false;
});

generateBtn.addEventListener("click", generateSubjects);

resetBtn.addEventListener("click", function () {
  subjectCount.value = "5";
  generateSubjects();
  error.textContent = "";
  results.hidden = true;
});

generateSubjects();

          